const list = document.querySelectorAll('.slides__gallery img')



if(screen.width < 1023) {
  Array.from(listImgGallery).forEach((el, i) => {
    console.log(i)
    el.addEventListener('touchstart', handleStart)
    el.addEventListener('touchmove',(event) => handleMove(event, i))
    el.addEventListener('touchend', (event) => handleEnd(event, i))
  })
}

let startingX

function handleStart(event) {
  console.log(event)
  let touches = event.changedTouches[0]
  console.log(touches)
  startingX = touches.clientX
 // startingX = event.changedTouches[0].clientX
  console.log(startingX)
}

function handleMove(event, i) {
  let touch = event.changedTouches[0]
  let change = startingX - touch.clientX
  if(i === list.length - 1) {
    return;
  }
  event.target.style.left = '-' + change + 'px'
  list[++i].style.left = (screen.width - change) + 'px'

  event.preventDefault()
}

function handleEnd(event, i) {
  let change = startingX - event.changedTouches[0].clientX
  let threshold = screen.width / 3
  ++i
  console.log(event.target)
  console.log(list[i])
  if(change < threshold) {
    event.target.style.left = 0
    list[i].style.left = '100%'
  } else {
    event.target.style.transition = 'all .3s'
    list[i].style.transition = 'all .3s'
    event.target.style.left = '-100%'
    list[i].style.left = '0'
  }
}